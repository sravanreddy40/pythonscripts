# Description
This script will downloads a JSON from s3, parses the Keys and writes to an empty txt file on s3. This will automatically recognises the new fields from new JSON files and will append to the txt file.

## Replace few variables 
Enter your AWS credentials, tablename and file names in the script before running it
